# YouAndAi 🧠🎮

A minimalist AI-powered text adventure where **you create the story** and Ai drives the world.

## 📦 Install

```bash


Setup Your Gemini API Key
Go to https://makersuite.google.com/app/apikey

Copy your key and paste it when you run the game !

open CMD And Type "youandai"
to start the game 


Gameplay Example :

AI: Dark cave. Torch flickers faintly.
You: I swing the sword forward.
AI: Torch falls. Shadows come closer.
