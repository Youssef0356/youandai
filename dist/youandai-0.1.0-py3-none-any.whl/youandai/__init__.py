"""YouAndAi text adventure game."""
