# YouAndAi 🧠🎮

A minimalist AI-powered text adventure where **you create the story** and Ai drives the world.

## 📦 Install

```bash


Setup Your Gemini API Key
Go to https://makersuite.google.com/app/apikey

Copy your key

Create a file named api_key.txt in your project folder

Paste your key into it (on a single line)

open CMD And Type "youandai"
to start the game 


Example :

AI: Dark cave. Torch flickers faintly.
You: I swing the sword forward.
AI: Torch falls. Shadows come closer.
